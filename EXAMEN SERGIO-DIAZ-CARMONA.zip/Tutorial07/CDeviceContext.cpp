#include "CDeviceContext.h"



CDeviceContext::CDeviceContext()
{
}


CDeviceContext::~CDeviceContext()
{
}
