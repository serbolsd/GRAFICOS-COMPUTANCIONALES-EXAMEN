#include "CPixelShader.h"



CPixelShader::CPixelShader()
{
}


CPixelShader::~CPixelShader()
{
}
