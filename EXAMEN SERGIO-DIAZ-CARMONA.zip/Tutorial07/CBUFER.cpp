#include "CBUFER.h"



CBUFER::CBUFER()
{
}


CBUFER::~CBUFER()
{
}
