#include "CLayout.h"



CLayout::CLayout()
{
}


CLayout::~CLayout()
{
}
