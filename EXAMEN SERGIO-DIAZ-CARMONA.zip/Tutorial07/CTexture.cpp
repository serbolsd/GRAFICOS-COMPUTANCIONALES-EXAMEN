#include "CTexture.h"



CTexture::CTexture()
{
}


CTexture::~CTexture()
{
}
