#include "CDevice.h"



CDevice::CDevice()
{

}


CDevice::~CDevice()
{
}
