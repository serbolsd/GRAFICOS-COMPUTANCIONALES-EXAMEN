#include "CVertexShader.h"



CVertexShader::CVertexShader()
{
}


CVertexShader::~CVertexShader()
{
}
