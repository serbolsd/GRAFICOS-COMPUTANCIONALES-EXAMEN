#include "CSwapChain.h"



CSwapChain::CSwapChain()
{
}


CSwapChain::~CSwapChain()
{
}


