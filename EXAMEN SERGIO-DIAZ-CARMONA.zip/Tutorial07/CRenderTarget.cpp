#include "CRenderTarget.h"



CRenderTarget::CRenderTarget()
{
}


CRenderTarget::~CRenderTarget()
{
}
